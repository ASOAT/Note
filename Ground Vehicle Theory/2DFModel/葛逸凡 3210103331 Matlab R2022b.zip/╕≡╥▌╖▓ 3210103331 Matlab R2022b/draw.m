Xs1 = out.Simulink.signals(1).values(1:59);
Ys1 = out.Simulink.signals(2).values(1:59);

plot(Xs1,Ys1)
legend('u = 10m/s')
hold on



